export const Config = {
  // API_URL: 'https://live-api.trackmykidz.com/api',
  // ACCESSKEYID: 'AKIAUOE6FO6IVESHEPFU',
  // SECRETKEYID: 'nib4A6pOtv8X9C7agxeWVhSrke7a9sUAGHgNT1AP',
  // REGION: 'us-east-2',
  // BUCKET: 'baftrendspostsartifactsprod',
  // STRIPE_PK: 'pk_live_51J3XIEHpP2GPUgoko3NIF9po8yOlaCzmspoAJNICnVU46PQFPW0nsJy6lsI0EFQossiQFO97ay5jn5c6xvhsoTXd00pP8etsw6'
  API_URL: "https://live-api.trackmykidz.com",
  ACCESSKEYID: "AKIAYHZBPYYBLVFK45L7",
  SECRETKEYID: "t/WCNdCPS/vy9FR+LngOnqh1+yC08pJPT61HgABF",
  REGION: "us-east-2",
  BUCKET: "baftrendspostsartifacts",
  STRIPE_PK:
    "pk_test_51L9vs2JJ9lJUrkO5jZFlA7HSWO0r8dYbnHplnQeSxuMYts0JFWQkamKrpqmP4Y5eUFDKFx116F8Sv1crhu2SKMPD00yOLQHeJB",
  GOOGLE_MAPS_KEY: "AIzaSyBBDJwlh5Mnc6Aa1l371eEOZ9G6Uc0ByWA",
};
