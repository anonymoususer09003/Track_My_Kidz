export const initialState = {
  instructorDetail: {},
  group: null,
  selectedActivity: null,
  selectedDependentActivity: [],
  childName: "",
  child: {},
  orgInstructors: {},
};
