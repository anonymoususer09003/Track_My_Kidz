import { StyleSheet, View, TouchableOpacity } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Button, ButtonProps, Text } from "@ui-kitten/components";
import React, { ReactText } from "react";
import Colors from "@/Theme/Colors";

const LinearGradientButton = (props: ButtonProps) => {
  // if (props.disabled) return <Button {...props}>{props.children}</Button>;
  return (
    <TouchableOpacity onPress={() => props.onPress()}>
      <LinearGradient
        colors={["#42ADCD", "#EC5ADD"]}
        style={styles.linearGradient}
      >
        <Text style={styles.buttonText}>
          {props.children == null ? "" : props.children.toString()}
        </Text>
      </LinearGradient>
    </TouchableOpacity>
    // <View style={[props.style, { backgroundColor: Colors.primary }]}>
    //   <Button {...props} status="control" appearance="ghost">
    //     {props.children == null ? "" : props.children.toString()}
    //   </Button>
    // </View>
  );
};
export default LinearGradientButton;
const styles = StyleSheet.create({
  topNav: {
    color: Colors.white,
  },
  text: {
    color: Colors.white,
  },
  bottom: {
    height: 45,
  },
  linearGradient: {
    flex: 1,
    paddingLeft: 15,
    paddingRight: 15,
    borderRadius: 20,
  },
  buttonText: {
    fontSize: 18,
    fontFamily: "Gill Sans",
    textAlign: "center",
    margin: 10,
    color: "#ffffff",
    backgroundColor: "transparent",
  },
  // buttonText: {
  //     flex: 1,
  //     borderRadius: 25,
  //     fontFamily: 'Gill Sans',
  //     textAlign: 'center',
  //     color: Colors.white,
  //     shadowColor: 'rgba(0,0,0, .4)', // IOS
  //     shadowOffset: { height: 1, width: 1 }, // IOS
  //     shadowOpacity: 1, // IOS
  //     shadowRadius: 1, //IOS
  //     justifyContent: 'center',
  //     alignItems: 'center',
  //     flexDirection: 'row',
  // },
});
