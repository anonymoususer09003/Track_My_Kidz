export { default as GetEtaGoogle } from "./GetEtaGoogle";
