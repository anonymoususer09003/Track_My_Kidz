export { default as AwsLocationTracker } from "./AwsLocationTracker";
