// import FindInstructorBySchoolOrg from './FindInstructorBySchoolOrg';

export { default as CreateInstructor } from "./CreateInstructor";
export { default as DeleteInstructor } from "./DeleteInstructor";
export { default as GetAllInstructors } from "./GetAllInstructors";
export { default as FindInstructorBySchoolOrg } from "./FindInstructorBySchoolOrg";
export { default as GetInstructor } from "./GetInstructor";
export { default as UpdateInstructor } from "./UpdateInstructor";
export { default as UpdateMultipleInstructor } from "./UpdateMultipleInstructor";
