import api from "@/Services";

export default async () => {
  // const res= await api.get(`/service-provider/appointments/self`);
  return [];
};
