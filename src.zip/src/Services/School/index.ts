export { default as CreateSchool } from './CreateSchool';
export { default as DeleteSchool } from './DeleteSchool';
export { default as GetAllSchools } from './GetAllSchools';
export { default as GetSchool } from './GetSchool';
export { default as UpdateSchool } from './UpdateSchool';
export { default as GetSchoolByFilters } from './GetSchoolByFilters';