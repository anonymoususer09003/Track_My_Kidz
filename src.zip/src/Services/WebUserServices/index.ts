export { default as ForgotPasswordWeb } from './ForgotPasswordWeb'
