export interface Menu {
  id: number
  name: string
  showingOrder: number
  title: string
}
