export interface VariablesGetDTO {
  annualProductActivation: number
  annualServiceActivation: number
  classVideoTime: number
  monthlyProductActivation: number
  monthlyServiceActivation: number
  postVideoTime: number
}
