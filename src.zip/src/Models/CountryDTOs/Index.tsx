export interface CountryDTO{
    name: string,
    iso2: string,
    iso3: string,
    phone_code: number,
    currency: string,
    capital: string
}
