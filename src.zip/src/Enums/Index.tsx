export enum Gender {
    male = 'male',
    female = 'female',
    other = 'other'
}
