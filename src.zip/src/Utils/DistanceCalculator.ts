function calculateDistance(lat1, lon1, lat2, lon2) {
    const earthRadius = 6371; // Radius of the earth in kilometers
  
    const dLat = toRadians(lat2 - lat1);
    const dLon = toRadians(lon2 - lon1);
  
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = earthRadius * c * 1000; // Convert to meters
  
    return distance;
  }
  
  function toRadians(degrees) {
    return degrees * (Math.PI / 180);
  }
  export {
      calculateDistance
  }
  // Usage
  const lat1 = 40.7128;
  const lon1 = -74.0060;
  const lat2 = 40.7129;
  const lon2 = -74.0060;
  
  const distance = calculateDistance(lat1, lon1, lat2, lon2);
  const isUnder100Meters = distance < 100;
  
  console.log(isUnder100Meters); // true if distance is under 100 meters, false otherwise
  